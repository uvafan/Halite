#include "map.hpp"

namespace hlt {
    Map::Map(const int width, const int height) : map_width(width), map_height(height) {
    }
}
